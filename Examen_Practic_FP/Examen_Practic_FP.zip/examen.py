def ub1(uppercase):
    with open ("my_file.txt", "r") as f:
        students = f.readlines()
    if uppercase == True:
        students = list(filter(lambda stud : str(stud.split(" ")[1].isupper()), students))
    elif not uppercase:
        students = list(filter(lambda stud: str(stud.split(" ")[1].islower()), students))
    print(students)

ub1(True)



class TodoList:
    def __init__(self, name):
        self.name = name
        self.todos = []

    def done(self, in_string):
        for i in self.todos:
            if in_string in self.todos:
                self.todos.remove(in_string)
                return i
        return MyException

class MyException(Exception):
    raise Exception ("NotFound")

class ExtraTodoList(TodoList):
    def __init__(self, name):
        super().__init__(name)
        self.done_count = 0

    def done(self, in_string):
       s = super().done(in_string)
       if type(s) == int:
           self.done_count += 1
       else:
           self.done_count -= 1

    def __add__(self, other):
        todo = ExtraTodoList(self.name)
        todo.name = self.name + other.name
        todo.done_count = self.done_count + other.done_count
        return todo

todo1 = ExtraTodoList("ceva")
#print(todo1.done("ceva"))

