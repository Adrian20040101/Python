from ui import UI

interface = UI()

def run():
    while True:
        interface.clear_screen()
        interface.show_options()
        if interface.get_option():
            break

    print ("Thank you for using our application!")


run()
