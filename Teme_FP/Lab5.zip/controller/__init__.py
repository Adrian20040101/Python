from repository import DataRepo
from model import Order, Client, CookedDish, Drink

class Controller(DataRepo.DataRepo):
    def __init__(self):
        super().__init__()
        self.currency = '$'
        self.time = 'min'
    def show_menu(self):
        data = self.load('menu.json')
        if self.check_for_empty_list(data):
            return 'Nothing to show'
        return data

    def return_orders(self):
        data = self.load('order.json')
        if self.check_for_empty_list(data):
            return 'No order has been made'
        return data

    def return_clients(self):
        data = self.load('client.json')
        if self.check_for_empty_list(data):
            return 'No clients have been found'
        return data

    def adding_order(self, orders, user_name, elements, location, order):
        id = self.get_id()
        dishes = []
        drinks = []
        print(elements)
        for element in elements:
            dish = CookedDish(id, element["portion"], element["price"],
                              element["duration"], element["name"])

            drink_data = element["drink"]
            drink = Drink(id, drink_data["ml"], drink_data["price"], drink_data["alc_vol"], drink_data["name"])
            self.adding_drink(drink)

            dishes.append(dish)
            drinks.append(drink)

        client = Client(id, user_name, location)
        self.adding_client(client)

        order = Order(id, client, dishes, drinks)
        if type(orders) == list:
            orders.append(order)
        else:
            orders = [order]
        self.save("order.json", orders)
        print('Order succesfully added')

    def removing_order(self, data):
        id = data.id
        self.remove_content("order.json", id)

    def adding_drink(self, drink):
        drinks = self.load("drink.json")
        drinks.append(drink)
        self.save("drink.json", drinks)


    def adding_client(self, client):
        clients = self.load("client.json")
        clients.append(client)
        self.save("client.json", clients)

    def removing_client(self, data):
        id = data.id
        self.remove_content("client.json", id)
        self.removing_order(data)

    def modifying_client(self, order, element_input, orders):
        new_value = input("Enter the new value: ")

        setattr(order.client, element_input, new_value)
        orders = list(map(lambda x: order if x.id == order.id else x, orders))
        self.save("order.json", orders)
        clients = self.return_clients()
        client = list(filter(lambda x: x.id == order.id, clients))[0]
        setattr(client, element_input, new_value)
        clients = list(map(lambda x: client if x.id == client.id else x, clients))
        self.save("client.json", clients)
        print('it has been modified')

    def modifying_order(self, menu_item, order,counter,replaced):
        orders = self.load("order.json")

        dish_name = menu_item["name"]
        dish_portion = menu_item["portion"]
        drink_name = menu_item["drink"]["name"]
        drink_quantity = menu_item["drink"]["ml"]
        drink_alc_vol = menu_item["drink"]["alc_vol"]
        drink_price = menu_item["drink"]["price"]
        price = menu_item["price"]
        duration = menu_item["duration"]
        order.dishes[replaced-1].name = dish_name
        order.dishes[replaced-1].price = price
        order.dishes[replaced-1].prep_time = duration
        order.dishes[replaced-1].portion = dish_portion
        order.drinks[replaced-1].name = drink_name
        order.drinks[replaced-1].quantity = drink_quantity
        order.drinks[replaced-1].alc_vol = drink_alc_vol
        order.drinks[replaced-1].price = drink_price


        for index,order in enumerate(orders):
            if index == counter:
                order.dishes[replaced-1] = order

        self.save("order.json", orders)

    def search_clients(self, user_input):
        clients = self.load("client.json")
        clients = list(filter(lambda x : user_input.lower() in x.name.lower() or user_input.lower() in x.address.lower(), clients))
        return clients

    def search_clients_by_name(self, user_input):
        clients = self.load("client.json")
        clients = list(filter(lambda x : user_input.lower() in x.name.lower(), clients))
        return clients

    def search_clients_by_address(self, user_input):
        clients = self.load("client.json")
        clients = list(filter(lambda x : user_input.lower() in x.address.lower(), clients))
        return clients