from datetime import datetime, timedelta
from functools import reduce

class Identifiable:
    def __init__(self, id):
        self.id = id

class Dish(Identifiable):
    def __init__(self, id, portion, price):
        super().__init__(id)
        self.portion = portion
        self.price = price

class CookedDish(Dish):
    def __init__(self, id, portion, price, prep_time, name):
        super().__init__(id, portion, price)
        self.prep_time = prep_time
        self.name = name
        self.time = datetime.now()
        self.exp_delivery_time = str(self.time + timedelta(minutes = int(prep_time)))

    def return_data(self):
        return {"dish" : self.name, "price" : self.price, "portion"  : self.portion, "preparation_time" : self.prep_time, "time" : str(self.time), "delivery time" : self.exp_delivery_time}

class Drink(Dish):
    def __init__(self, id, portion, price, alc_vol, name):
        super().__init__(id, portion, price)
        self.alc_vol = alc_vol
        self.name = name

    def drink_data(self):
        return {"drink" : self.name, "price" : self.price, "quantity" : self.portion, "alc_vol" : self.alc_vol}

class Client(Identifiable):
    def __init__(self, id, name, address):
        super().__init__(id)
        self.name = name
        self.address = address
        self.client_since = str(datetime.now()).split(" ")[0]

    def get_client_data(self):
        return {"name" : self.name, "address" : self.address, "id" : self.id, "client_since" : self.client_since}

    def check_date_is_today(self):
        today = str(datetime.now()).split(" ")[0]
        if today == self.client_since:
            return "Today"
        return self.client_since

class Order(Identifiable):
    def __init__(self, id, client, dishes, drinks):
        super().__init__(id)
        self.currency = '$'
        self.time = 'min'
        self.client = client
        self.dishes = dishes
        self.drinks = drinks

    def get_total_price(self):
        total = 0

        for dish,drink in zip(self.dishes,self.drinks):      #restrange listele la un numar egal de elemente
            total += int(dish.price) + int(drink.price)

        return total


    def get_prep_time(self):
        prep_time = 0

        for dish in self.dishes:
            prep_time += int(dish.prep_time)

        return prep_time

    def __get_invoice(self, client, dishes, drinks):
        total = self.get_total_price()
        return {"name" : client.get_client_data()["name"],
                "location" : client.get_client_data()["address"],
                "dishes" : dishes,
                "drinks" : drinks,
                "preparation_time" : str(self.get_prep_time()),
                "dish_delivery": str(dishes[0].time + timedelta(minutes=self.get_prep_time())),
                "dish_time" : str(dishes[0].time),
                "total" : total}

    def separate_invoice_data(self):
        print("____________________________________________________________________________________________________")

    def separate_type(self):
        print("__________________________________________DRINK___________________________________________________")


    def order_info(self):
        data = self.__get_invoice(self.client, self.dishes, self.drinks)
        print(f"Name: {data['name']}")
        print(f"Location: {data['location']}")
        for element in data["dishes"]:
            print(f"Dish: {element.name}")
            print(f"Dish portion: {element.portion}")
            print(f"Dish price: {element.price}{self.currency}")
            print(f"Preparation time: {element.prep_time} {self.time}")
            if data["dishes"].index(element) != len(data["dishes"])-1:
                self.separate_invoice_data()
        self.separate_type()
        for element in data["drinks"]:
            print(f"Drink: {element.name}")
            print(f"Drink quantity: {element.portion}ml")
            print(f"Drink's price: {element.price}{self.currency}")
            if data["drinks"].index(element) != len(data["drinks"]) - 1:
                self.separate_invoice_data()
        print(f"Made on: {data['dish_time']}")
        print(f"Expected delivery: {data['dish_delivery']}")

    def return_invoice(self):
        data = self.__get_invoice(self.client, self.dishes, self.drinks)
        if data:
            for element in data["dishes"]:
                print(f"Dish: {element.name}")
                print(f"Dish portion: {element.portion}")
                print(f"Dish price: {element.price}{self.currency}")
                print(f"Preparation time: {element.prep_time} {self.time}")
                if data["dishes"].index(element) != len(data["dishes"]) - 1:
                    self.separate_invoice_data()
            self.separate_type()
            for element in data["drinks"]:
                print(f"Drink: {element.name}")
                print(f"Drink quantity: {element.portion}ml")
                print(f"Drink's price: {element.price}{self.currency}")
                if data["drinks"].index(element) != len(data["drinks"]) - 1:
                    self.separate_invoice_data()
            print(f"Total: {data['total']}{self.currency}")
            print(f"Made on: {data['dish_time']}")
            print(f"Paid on: {data['dish_delivery']}")