import json
import uuid
import pickle

class DataRepo:

    def check_for_empty_list(self, data):
        return len(data) == 0

    def load(self, file_name):
        """aceasta functie returneaza data gasita in fisierul dat ca parametru"""

        try:
            with open(file_name, "r", encoding='utf-8') as file:
                data = json.loads(file.read())
        except Exception as error:
            try:
                with open(file_name, "rb") as file:
                    data = pickle.loads(file.read())
            except Exception as error:
                with open(file_name, "wb") as file:
                    file.write(pickle.dumps([]))
                    return []
            else:
                return data
        else:
            return data

    def save(self, file_name, dta, convert_only = False):
        data = pickle.dumps(dta)
        if convert_only:
            return data
        with open (file_name, "wb") as file:
            file.write(data)

    def write_to_file(self, file_name):
        self.save(file_name, [])

    def read_file(self, file_name):
        with open (file_name, 'rb') as file:
            return file.read()



    def get_id(self):
        id = str(uuid.uuid4())
        return id

    def update_content(self, file_name, id, content):
        data = self.load(file_name)
        if self.check_for_empty_list(data):  #if len(data) == 0
            return 'Nothing has been found'
        data = list(map(lambda x :content if x["id"] == id else x, data))[0]
        self.save(file_name, data)

    def remove_content(self, file_name, id):
        data = self.load(file_name)
        if self.check_for_empty_list(data):
            return 'Nothing to remove'
        data = list(filter(lambda x : x.id != id, data))
        self.save(file_name, data)
