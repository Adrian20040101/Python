from DataRepo import DataRepo
from os import chdir

class OrderRepo(DataRepo):
    def __init__(self, filename):
        self.filename = filename
        super().__init__()

    def convert_to_string(self) :
        data = self.load(self.filename)
        converted_string = self.save(self.filename, data, True)
        return converted_string

    def convert_from_string(self):
        data = self.load(self.filename)
        return data

chdir ('../')
