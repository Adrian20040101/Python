from repository.DrinkRepo import  DrinkRepo
from repository.CookedDishRepo import CookedDishRepo
from model import Drink, CookedDish
from os import chdir

def test_add_drink(id, name, portion, price, alc_vol, function):
    drink_repo = DrinkRepo("drink.json")
    drink = Drink(id, portion, price, alc_vol, name)
    data = drink_repo.load('drink.json')
    data.append(drink)
    drink_repo.save('drink.json', data)
    drink = drink_repo.load('drink.json')[-1]    #iau ultimul element din lista

    try:
        assert drink.id == id
        assert drink.name == name
        assert drink.portion == portion
        assert drink.price == price
        assert drink.alc_vol == alc_vol
    except Exception as error:
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")

    finally:         # orice se intampla ajunge la final, dupa ce trece de try
        final_data = drink_repo.load("drink.json")
        final_data = list(filter(lambda element : element != drink, final_data))
        drink_repo.save("drink.json", final_data)

# adauga un tip de mancare
def test_add_cooked_dish(id, name, portion, price, prep_time, function):
    cooked_dish_repo = CookedDishRepo("dish.json")
    cooked_dish = CookedDish(id, portion, price, prep_time, name)
    data = cooked_dish_repo.load('dish.json')
    data.append(cooked_dish)
    cooked_dish_repo.save('dish.json', data)
    dish = cooked_dish_repo.load('dish.json')[-1]  # iau ultimul element din lista

    try:
        assert dish.id == id
        assert dish.name == name
        assert dish.portion == portion
        assert dish.price == price
        assert dish.prep_time == prep_time
    except Exception as error:
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")

    finally:  # orice se intampla ajunge la final, dupa ce trece de try, revenind la contentul initial, pentru a nu altera fisierul original
        final_data = cooked_dish_repo.load("dish.json")
        final_data = list(filter(lambda element: element != dish, final_data))
        cooked_dish_repo.save("dish.json", final_data)


chdir('../')
test_add_drink(id='10', name='Test', portion='123', price='15', alc_vol='45', function = test_add_drink)
test_add_cooked_dish(id='10', name='Test', portion='123', price='15', prep_time='50', function = test_add_cooked_dish)