from os import chdir
from controller import Controller
from helper import add_order, read_orders

def test_convert_and_save_orderinstance(function):
    orders = read_orders()
    try:
        add_order()
    except Exception as error:
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")
    finally:
        orders.pop()
        Controller().save('order.json', orders)

chdir('../')
test_convert_and_save_orderinstance(test_convert_and_save_orderinstance)