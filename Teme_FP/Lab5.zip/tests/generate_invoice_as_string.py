from model import Order
from os import chdir
from controller import Controller

def test_generate_invoice(function):
    #testam ca se genereaza invoice ptr ultimul client
    try:
        element = Controller().load("order.json")[-1]
        Order(element.id, element.client, element.dish, element.drink).return_invoice()
    except Exception as error:
        print(error)
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")

chdir("../")
test_generate_invoice(test_generate_invoice)