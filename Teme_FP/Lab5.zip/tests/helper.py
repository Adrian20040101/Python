from ui import UI

def search_client(criteria = 'name'):
    UI().show_clients()
    if criteria.lower() == 'name':
        user_input = input("Search a client by parts of their name: ")
        found_clients = UI().search_clients_by_name(user_input)
        if len(found_clients):
            for index, element in enumerate(found_clients):
                client = element.get_client_data()
                element_count = index + 1
                print(f'{element_count}.')
                print(f"ID: {client['id']}")
                print(f"Name: {client['name']}")
                print(f"Location: {client['address']}")
                print(f"Client since: {element.check_date_is_today()}")
                UI().separate_elements()
            return
        print("No clients have been found!")
    else:
        user_input = input("Search a client by parts of their address: ")
        found_clients = UI().search_clients_by_address(user_input)
        if len(found_clients):
            for index, element in enumerate(found_clients):
                client = element.get_client_data()
                element_count = index + 1
                print(f'{element_count}.')
                print(f"ID: {client['id']}")
                print(f"Name: {client['name']}")
                print(f"Location: {client['address']}")
                print(f"Client since: {element.check_date_is_today()}")
                UI().separate_elements()
            return
        print("No clients have been found!")

def add_order():
    UI().add_order()

def read_orders():
    return UI().return_orders()