from os import chdir
from helper import read_orders

def test_read_and_convert_orderinstance(function):
    try:
        data = read_orders()
    except Exception as error:
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")
        if len(data):
           return data[0]

chdir('../')
test_read_and_convert_orderinstance(test_read_and_convert_orderinstance)