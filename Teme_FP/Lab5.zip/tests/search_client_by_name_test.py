from os import chdir
from helper import search_client

def test_search_client_by_name(function):
    # aici testam functionalitatea cautarii numelui unui client, astfel ca si daca se introduce numele unui client care nu apare in baza de date, testul va avea rezultatul "passed"
    try:
        search_client()
    except Exception as error:
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")

chdir('../')
test_search_client_by_name(function = test_search_client_by_name)