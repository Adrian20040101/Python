from os import chdir
from controller import Controller

from ui import UI

def test_update_client_name(function):
    #in fisierul order.json apar si clientii pe care ii testam
    data = Controller().load('order.json')
    try:
        UI().update_order()
    except Exception as error:
        print(f"{function.__name__} failed the test")
    else:
        print(f"{function.__name__} passed the test")
    finally:
        Controller().save('order.json', data)

chdir("../")
test_update_client_name(test_update_client_name)
