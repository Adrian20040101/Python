from controller import Controller
import os
from colorama import Fore

class UI(Controller):
    def __init__(self):
        super().__init__()
        self.functions = {"1" : self.get_menu,
                        "2" : self.get_orders,
                        "3" : self.show_clients,
                        "4" : self.add_order,
                        "5" : self.remove_order,
                        "6" : self.remove_client,
                        "7" : self.update_order,
                        "8" : self.show_found_clients,
                        "9" : self.generate_invoice}
        self.options = ["Get menu", "Get orders", "Get clients", "Add order", "Remove order", "Remove clients", "Update order", "Search clients", "Show invoice"]

    def clear_screen(self):
        os.system("cls")

    def show_options(self):
        print('0. Exit')
        for index,option in enumerate(self.options):
            print(f'{index+1}.{option}')

    def get_option(self):
        option = input("Choose what you would like to do: ")
        if not int(option):
            return "exit"
        if self.functions.get(option):
            self.functions[option]()
        else:
            print("Can't use that option!")
        while True:
            back = input("Would you like to go back?").lower()
            if back == 'yes':
                return
            #self.clear_screen()
            self.functions[option]()

    def separate_elements(self, count = 100):
        print('_' * count + '\n')


    def get_menu(self):
        menu_items = self.show_menu()
        if type(menu_items) == list:
            for index,element in enumerate(menu_items):
                element_count = index + 1
                print (f'{element_count}.')
                print (f"Name: {element['name']}")
                print (f"Drink: {element['drink']['name']}")
                print (f"Drink quantity: {element['drink']['ml']} ml")
                print (f"Drink's alc.vol: {element['drink']['alc_vol']}")
                print (f"Drink's price: {element['drink']['price']}")
                print (f"Price: {element['price']}{self.currency}")
                self.separate_elements()
            return
        print (menu_items) # nu va returna o lista, ci un mesaj


    def get_orders(self):
        order_items = self.return_orders()
        if type(order_items) == list:
            for index,element in enumerate(order_items):
                element_count = index + 1
                print (f'{element_count}.')
                element.order_info()
                self.separate_elements()
            return
        return print(order_items)   # este un mesaj

    def add_order(self):
        print ("Menu: ")
        self.get_menu()
        print ('\n')
        print("Adding order: ")
        user_name = input("Name: ")
        location = input("Location: ")
        elements = []

        while True:
            order = input("Order no. :")
            try:
                order = int(order)
            except Exception as err:
                print('Order has to be a number')
            else:
                if order in list(range(len(self.show_menu()) + 1)):
                    elements.append(self.show_menu()[order-1])
                    if input("Would you like add another menu? ") == "yes":
                        continue
                    orders = self.load("order.json")
                    self.adding_order(orders, user_name, elements, location, order)
                    return
                else:
                    print ('Number out of range')


    def remove_order(self):
        self.get_orders()
        data = self.return_orders()
        if type(data) != list:
            return

        while True:
            user_input = input("Choose the number of the order you want to remove: ")
            try:
                user_input = int(user_input)
            except Exception as err:
                print('Order has to be a number')
            else:
                if user_input in list(range(len(data) + 1)):
                    self.removing_order(data[user_input-1])
                    print (f'Order with id {data[user_input-1].id} has been removed')
                    return
                else:
                    print('Number out of range')

    def show_clients(self):
        data = self.return_clients()
        if type(data) == list:
            for index, element in enumerate(data):
                client = element.get_client_data()
                element_count = index + 1
                print(f'{element_count}.')
                print(f"ID: {client['id']}")
                print(f"Name: {client['name']}")
                print(f"Location: {client['address']}")
                print(f"Client since: {element.check_date_is_today()}")
                self.separate_elements()
            return
        print(data)

    def remove_client(self):
        self.show_clients()
        data = self.return_clients()
        if type(data) != list:
            return

        while True:
            user_input = input("Choose the number of the client you want to remove: ")
            try:
                user_input = int(user_input)
            except Exception as err:
                print('It has to be number')
            else:
                if user_input in list(range(len(data) + 1)):
                    self.removing_client(data[user_input - 1])
                    print(f'Client with id {data[user_input - 1].id} has been removed')
                    return
                print('Number out of range')

    def update_order(self):
        orders = self.return_orders()
        self.get_orders()
        while True:
            user_input = input("Choose which order you would like to modify: ")
            try:
                user_input = int(user_input)
            except Exception as error:
                print("It has to be a number")
            else:
                if user_input in list(range(len(orders)+1)):
                    order = orders[user_input-1]
                    element_input = input(f"Choose what you would like to modify to the order with ID {orders[user_input-1].id}: name, address or menu").lower()
                    if element_input == "menu":
                        self.get_menu()
                        replaced = input("Which of the menus would you like to modify?")
                        if not replaced.isdigit():
                            continue
                        replaced = int(replaced)
                        while True:
                            order = input("Menu no. :")
                            try:
                                order = int(order)
                            except Exception as err:
                                print('Menu no. has to be a number')
                            else:
                                menu = self.show_menu()
                                if order in list(range(len(menu) + 1)):
                                    self.modifying_order(menu[order - 1], orders[user_input - 1],order-1,replaced-1)
                                    print('It has been modified')
                                    return
                                else:
                                    print('Number out of range')
                            print("Can't modify that attribute")
                    try:
                        element = getattr(order.client, element_input)
                    except Exception as error:
                        print("Can't modify that attribute")
                    else:
                        self.modifying_client(order, element_input, orders)
                        return

                else:
                    print("Number not in range")

    def show_found_clients(self):
        self.show_clients()
        user_input = input("Search a client by their name or address or part of those criterias: ")
        found_clients = self.search_clients(user_input)
        if len(found_clients):
            for index, element in enumerate(found_clients):
                client = element.get_client_data()
                element_count = index + 1
                print(f'{element_count}.')
                print(f"ID: {client['id']}")

                if user_input.lower() in client["name"].lower():
                    i = client['name'].lower().index(user_input.lower())
                    if i == 0:
                        print(f"Name: {Fore.GREEN}{client['name'][0:len(user_input)]}{Fore.RESET}{client['name'][len(user_input):]}")
                    else:
                        print(f"Name: {client['name'][0:i]}{Fore.GREEN}{client['name'][i:i+len(user_input)]}{Fore.RESET}{client['name'][i+len(user_input):]}")
                else:
                    print(f"Name: {client['name']}")

                if user_input.lower() in client["address"].lower():
                    i = client['address'].lower().index(user_input.lower())
                    if i == 0:
                        print(f"Location: {Fore.GREEN}{client['address'][0:len(user_input)]}{Fore.RESET}{client['address'][len(user_input):]}")
                    else:
                        print(f"Location: {client['address'][0:i]}{Fore.GREEN}{client['address'][i:i+len(user_input)]}{Fore.RESET}{client['address'][i+len(user_input):]}")
                else:
                    print(f"Location: {client['address']}")
                print(f"Client since: {element.check_date_is_today()}")
                self.separate_elements()
            return
        print("No clients have been found!")

    def generate_invoice(self):
        orders = self.return_orders()
        self.get_orders()
        user_input = input("Choose which order you'd like to generate an invoice to: \n" )

        try:
            user_input = int(user_input)
        except Exception as error:
            print("It has to be a number")
        else:
            if user_input in list(range(len(orders) + 1)):
                print(f"Invoice for order with ID {orders[user_input-1].id}")
                self.separate_elements()
                orders[user_input-1].return_invoice()
                self.separate_elements()
                print("Thank you for choosing us! We hope you'll come back soon!")
            else:
                print("Number not in range")
